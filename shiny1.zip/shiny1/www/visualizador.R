visualizar<-function(){
  tabPanel("Visualizaciones",
           tabsetPanel(
             tabPanel("Visualizacion 1",
                     sidebarLayout(
                       sidebarPanel(
                         titlePanel("Panel de control"),
                         h5("Controles"),
                         sliderInput("idSlider1","Primeros 20 alumnos", min = 0, max = 20,step=1, value=c(1,5))
                       ),
                       mainPanel(
                         h1("Salida de datos"),
                         plotOutput("idSalida1")
                       )
                     )),
             tabPanel("Visualizacion 2",
                      sidebarLayout(
                        sidebarPanel(
                          titlePanel("Panel de control"),
                          h5("Controles"),
                          sliderInput("ages","Edades:", min = 15, max = 25,step=1, value=c(15,17))
                        ),
                        mainPanel(
                          h1("Salida de datos"),
                          plotOutput("idSalida2")
                        )
                      )),
             tabPanel("Visualizacion 3",
                      sidebarLayout(
                        
                        sidebarPanel(
                          titlePanel("Panel de control"),
                          h5("Controles"),
                          sliderInput("equis", "Estudiante : ",min = 0, max = 50,step=1,value=c(1,5))),
                        mainPanel(h1("Salida de datos"),
                          plotOutput("idSalida4")))
             )  
             
           )
           )
  
}
