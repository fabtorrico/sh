Exploracion = function(){
  tabPanel("Exploracion y consultas",
           titlePanel("Consultas: "),
           sidebarLayout(
             sidebarPanel(
                    selectInput('consulta',
                                "Selecciona consulta",
                                c("Ninguna"="ninguna",
                                  "Estudiantes mujeres mayores de 18 anios que vivan en la ciudad (Urban)" = "c1",
                                  "Estudiantes del genero masculino con calificacion menor a 10 en el primer grado del periodo de la materia matematica"= "c2",
                                  "Cantidad de estudiantes por nota en la materia de matematica" = "c3",
                                  "Estudiantes del genero femenino con nota aprobatoria en el segundo grado del periodo de la materia de portuguese del colegio Mousinho da Silveira"= "c4",
                                  "Estudiantes varones menor a 18 anios que vivan en el campo (Rural) y con familias mayor a 3 miembros" = "c5",
                                  "Estudiantes del colegio de Gabriel Pereira GP que tienen familias separadas y saber su apoderado de los cursos de Matematica (x)"="c6",
                                  "Padres de familias que tengan estudios primarios (1) y sean de la zona Rural del colegio de GP"="c7",
                                  "Estudiantes cuyos padres tengan el trabajo de madre sea ama de casa y padre sea de servicios de la zona urbana y sean del colegio Mousinho da Silveira (MS)" ="c8",
                                  "Apoderados de estudiantes menores a 18 cuyos padres no esten separados, la escuela sea MS, el apoderado de ambos cursos de matemática y portugues sea la madre"="c9",
                                  "Los estudiantes que pagan por clases de matematicas en el colegio de GP y MS, y que tengan el apoyo economico de sus familiares."="c10",
                                  "Estudiantes del genero masculino con calificacion menor a 10 en el primer grado del periodo de la materia matematica"="c11",
                                  "Cantidad de estudiantes por nota en la materia de matematica"="c12",
                                  "Estudiantes del genero femenino con nota aprobatoria en el segundo grado del periodo de la materia de portuguese del colegio Mousinho da Silveira"="c13"))
                    ),
             mainPanel(
               dataTableOutput("exploracion")
               )
             )
           )
}