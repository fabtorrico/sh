modelo = function(){
  tabPanel("modelo",
           h1("Modelo regresional"),
           fluidRow(
             column(2,
                    selectInput('modx',"Selecciona columna",c('G1.x','G2.x','G3.x'))
             ),
             column(2,
                    selectInput('mody',"Selecciona columna",c('G1.y','G2.y','G3.y'))
             ),
           plotOutput('modelo')
  )
  )
}