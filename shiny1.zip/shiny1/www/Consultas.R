Consultas = function(){
  tabPanel("Consultas",
           h1("Consultas:"))
}