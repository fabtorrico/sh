Preparacion = function(){
  tabPanel("Preparacion de los datos",
           
           sidebarLayout(
             sidebarPanel(
               h4("Datos"),
               
               radioButtons('q', 'Quitar NA',
                            c(Si='a',
                              No=FALSE),
                            selected = 'a'),
               radioButtons('n', 'Normalizar',
                            c(Si='c',
                              No=FALSE),selected = 'c')
             ),
             mainPanel(h4("Salida de datos"),
                       dataTableOutput("fi"))
             
           )
  )
}