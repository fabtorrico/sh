Inputaciondedatos = function(){
  tabPanel("Recoleccion de Datos",
           titlePanel("Carga un dataset"),
           sidebarLayout(
             sidebarPanel(
               radioButtons('tipoarchivo', 'Elija la extension:',
                            c('.csv'="csv",
                              '.tsv'="tsv",
                              '.xml' ="xml",
                              '.json'="json"),
                            "csv"),
               tags$hr(),
               fileInput('file', 'Elige el archivo',
                         accept = c(
                           'text/csv',
                           'text/comma-separated-values',
                           'text/tab-separated-values',
                           'text/plain',
                           '.csv',
                           '.tsv',
                           '.xml',
                           '.json'
                         )
               ),
               tags$hr(),
               checkboxInput('header', 'Header', TRUE),
               radioButtons('sep', 'Separador',
                            c(Coma=',',
                              Tab='\t'),
                            ','),
               tags$hr(),
               radioButtons("disp", "Mostrar",
                            choices = c(Head = "head",
                                        All = "all"),
                            selected = "head")
               
             ),
             mainPanel(
               dataTableOutput('tablainput')
             )
           )
  )
}
