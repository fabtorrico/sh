Pantallaprincipal<-function(){
  tabPanel("Pantalla de Presentacion",
          
           p(strong(h1("Administracion de la informacion",align="center"))),
           h2("Proyecto Final",align="center"),
           img(src = "Adminfo.png",height = 400, width = 1000),
           h2(),
           h2(),
           p(strong(h3("Integrantes:",align="center"))),
           h5("Mauricio Rodriguez",align="center"),
           h5("Luigui Parodi",align="center"),
           h5("Fabricio Torrico",align="center"),
           h2(),
           h2(),
           p(strong(h3("Profesor:",align="center"))),
           h5("Walter cueva",align="center"),
           h1(),
           h1(),
           h1("2018",align="center")
           
           
           )
}
