#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
#install.packages(c("shiny","ggplot2","dplyr","wordcloud"))
#install.packages("stringi",type="mac.binary")
#install.packages(c("shinyAce","sendmailR"))
#install.packages("XML")

rsconnect::setAccountInfo(name='marooc2',
                          token='BBFC02A42A2E49739EB7BE279089071E',
                          secret='GCjjRkBci53W9f20xIlS243gcUwLcYnGtrjsAlop')

library(shiny)
library(ggplot2)
library(XML)
library(dplyr)
#library(wordcloud)
#library(mailR)
library(shinyAce)
library(sendmailR)
library(jsonlite)

source("www/PanelPrincipal.R")
source("www/Inputaciondedatos.R")
source("www/Preparacion.R")
source("www/Exploracion.R")
source("www/modelo.R")
source("www/visualizador.R")
source("www/email.R")

# Define UI for application that draws a histogram
ui <- fluidPage(
  tabsetPanel(
    Pantallaprincipal(),
    Inputaciondedatos(),
    Preparacion(),
    Exploracion(),
    modelo(),
    visualizar(),
    email()
  )
)
# Define server logic required to draw a histogram
server <- function(input, output, session) 
  {
  
  observe({
    if(is.null(input$send) || input$send==0) return(NULL)
    from <- isolate(input$from)
    to <- isolate(input$to)
    subject <- isolate(input$subject)
    msg <- isolate(input$message)
    sendmail(from, to, subject, msg)
  })
  
  
  output$tablainput <- renderDataTable({
      
    inFile <- input$file
    
    if (is.null(inFile))
      return(NULL)
    
    if(input$tipoarchivo == "csv"){
    df <- read.csv(inFile$datapath,header = input$header,
                     sep = input$sep)
       if(input$disp == "head")
         return(head(df))
        else
         return(df)
    }
    
    if(input$tipoarchivo =="tsv"){
      df <- read.csv(inFile$datapath,header = input$header,
                   sep = input$sep)
      if(input$disp == "head")
        return(head(df))
      else
        return(df)
      return(df)
    }
    
    if(input$tipoarchivo =="xml"){
      df <- xmlToDataFrame(inFile$datapath)
      return(df)
      }

    if(input$tipoarchivo =="json"){
      df <- fromJSON(readLines(inFile$datapath))
      return(df)
    }
    
  })
  
  output$fi <- renderDataTable({
    
    inFile <- input$file
    
    if(input$q=='a'){
      
      NAs = function(df)
      {
        for(i in 1:NCOL(df))
        {
          df=filter(df, !is.na(df[,i]))
        }
        
        return(df)
      }
    }
    
    
    if(input$n=='c'){
      
      Normalizar = function(file)
      {
        Normalizar = function(df)
        {
          return(data.frame(scale(df, center = TRUE)))
        }
        Normalizar(dt)
      }
    }
    
    read.csv(inFile$datapath)
  })
  
  output$preparacion <- renderDataTable({
    
    inFile <- input$file
    
    if (is.null(inFile))
      return(NULL)
    
    df <- read.csv(inFile$datapath)
    
  })
  
  output$exploracion <- renderDataTable({
    
    inFile <- input$file
    if (is.null(inFile))
      return(NULL)
    
    df <- read.csv(inFile$datapath)
    
    if(input$consulta =="ninguna")
      return(df)
    
    if(input$consulta == "c1"){
      dfc1<-subset(df, age > 18, select = c(sex, age, address)) %>%
        filter(sex == "F", address == "U")
      return(dfc1)
    }
    
    if(input$consulta == "c2"){
      EMM10<-subset(df, G1.x < 10, select = c(sex,G1.x))%>%
        filter(sex == "M")
      return(EMM10)
    }
    
    if(input$consulta == "c3"){
      CEPM<- df %>% select(G1.x) %>% count(G1.x)
      return(CEPM)
    }
    
    if(input$consulta =="c4"){
      EFNA<- subset(df, G2.y > 10, select = c(sex,G1.x,school))%>%
        filter(sex == "M",school == "MS")
      return(EFNA)
    }
    
    if(input$consulta =="c5"){
      MH<-subset(df, age < 18, select = c(sex, age, address, famsize)) %>%
        filter(sex == "M", address == "R", famsize == "GT3")
      return(MH)
    }
    
     if(input$consulta =="c6"){
       MH2<-subset(df, select = c(school, age, Pstatus, guardian.x)) %>%
         filter(school == "GP", Pstatus == "A")
      return(MH2)
     }
    
    if(input$consulta =="c7"){
      PN<-subset(df, select = c(school, sex, age, Medu, Fedu)) %>%
        filter(school == "GP", Fedu == "1", Medu == '1')
      return(PN)
    }
    
    if(input$consulta =="c8"){
      MFJ<-subset(df, select = c(school, sex, age, Mjob, Fjob)) %>%
        filter(school == "MS", Mjob == "at_home", Fjob == "services")
      return(MFJ)
    }
    
    if(input$consulta =="c9"){
      MFJ2<-subset(df, age < 19, select = c(school, sex, age, Pstatus, guardian.x, guardian.y)) %>%
        filter(school == "MS", Pstatus == "T", guardian.x == "mother", guardian.y == "mother")
      return(MFJ2)
    }
    
    if(input$consulta =="c10"){
      SPC <- subset(df, select = c(school, sex, age, paid.x, famsup.x)) %>%
        filter(famsup.x == "yes", paid.x == "yes")
      return(SPC)
    }
    
    if(input$consulta =="c11"){
      EMM10<-subset(df, G1.x < 10, select = c(sex,G1.x))%>%filter(sex == "M")
      return(EMM10)
    }
    
    if(input$consulta =="c12"){
      CEPM<- df %>% select(G1.x) %>% count(G1.x)
      return(CEPM)
      
    }
    
    if(input$consulta =="c13"){
      EFNA<- subset(df, G2.y > 10, select = c(sex,G1.x,school))%>%filter(sex == "M",school == "MS")
      return(EFNA)
    }
    
    
  })
  
  
  
  output$modelo <- renderPlot({
  
    inFile <- input$file
    
    if (is.null(inFile))
      return(NULL)
    df <- read.csv(inFile$datapath)
    
    regresion <- lm(G1.x ~ G2.x , data = df)
    plot(df$G1.x, df$G2.x, xlab = "Notas primer periodo mate", ylab = "Notas segundo periodo mate")
    abline(regresion)
  })
  
  output$idSalida1<-renderPlot({
    
    inFile <- input$file
    
    if (is.null(inFile))
      return(NULL)
    
    df <- read.csv(inFile$datapath)
    
    df = df[,c("X","traveltime.x")]
    datt <- reactive({
      testt <- df[df$X %in% seq(from=min(input$idSlider1),to=max(input$idSlider1),by=1),]
    })
    ggplot(datt(),aes(x=X,y=traveltime.x,fill=traveltime.x))+ 
      xlab("Alumno") + 
      ylab("Tiempo en que demora en llegar al colegio")+geom_bar(stat="identity")
  },height = 400,width = 600)
  
  output$idSalida2 <- renderPlot({
    
    inFile <- input$file
    
    if (is.null(inFile))
      return(NULL)
    
    df <- read.csv(inFile$datapath)
    
    df = df[,c("age","G3.y")]
    dat <- reactive({
      test <- df[df$age %in% seq(from=min(input$ages),to=max(input$ages),by=1),]
    })
    ggplot(dat(),aes(x=age,y=G3.y))+geom_point(colour='blue')+ xlab("Edades") + ylab("Nota en el curso de portugues tercer periodo")
  },height = 400,width = 600)
   
  output$idSalida4 <- renderPlot({
     
     inFile <- input$file
     
     if (is.null(inFile))
       return(NULL)
     
     df <- read.csv(inFile$datapath)
     
     df = df[,c("X","G3.y")]
     dat <- reactive({
       test <- df[df$X %in% seq(from=min(input$equis),to=max(input$equis),by=1),]
     })
     ggplot(dat(),aes(x=X,y=G3.y))+geom_point(colour='red')+ xlab("Alumno") + ylab("Nota en el curso de portugues tercer periodo")
   },height = 400,width = 600)
  
  
  
  
  {
    x=c(1,3,13,12,16,14,18,13,12,16,13)
    y=c(16,12,13,14,15,12,16,11,13,18,17)
    dt = data.frame(x,y)
    
    
    #Imputacion
    Imputacion = function(df)
    {
      for(i in 1:NCOL(df))
      {
        df=filter(df, !is.na(df[,i]))
      }
      
      return(df)
    }
    #Normalizacion
    Normalizar = function(df)
    {
      return(data.frame(scale(df, center = FALSE)))
    }
    Normalizar(dt)
    }
}

shinyApp(ui = ui, server = server)


